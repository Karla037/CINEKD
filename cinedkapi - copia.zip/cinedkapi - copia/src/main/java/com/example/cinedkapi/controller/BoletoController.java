package com.example.cinedkapi.controller;

import com.example.cinedkapi.model.Boleto;
import com.example.cinedkapi.service.BoletoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/boletos")
public class BoletoController {

    @Autowired
    private BoletoService boletoService;

    @PostMapping("/crear")
    public ResponseEntity<Boleto> crearBoleto(@RequestBody Boleto boleto) {
        Boleto nuevoBoleto = boletoService.crearBoleto(boleto);
        return ResponseEntity.ok(nuevoBoleto);
    }

    @GetMapping("/listar")
    public ResponseEntity<Iterable<Boleto>> listarBoletos() {
        return ResponseEntity.ok(boletoService.listarBoletos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Boleto> obtenerBoletoPorId(@PathVariable Long id) {
        Boleto boleto = boletoService.obtenerBoletoPorId(id);
        return ResponseEntity.ok(boleto);
    }
}
