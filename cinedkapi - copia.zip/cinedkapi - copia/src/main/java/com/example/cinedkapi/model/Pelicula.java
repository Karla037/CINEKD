package com.example.cinedkapi.model;

import jakarta.persistence.*;
import java.util.Set;

@Entity
@Table(name = "PELICULA")
public class Pelicula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String fechaEstreno;

    @Column(nullable = false)
    private String detalles;

    @Column(nullable = false)
    private String estado;

    // Relación Many-to-One con la entidad Funcion
    @ManyToOne
    @JoinColumn(name = "FUNCION_ID_FUNCION", nullable = false)
    private Funcion funcion;

    // Relación Many-to-Many con Categoria
    @ManyToMany
    @JoinTable(
            name = "PELICULA_has_CATEGORIA",
            joinColumns = @JoinColumn(name = "PELICULA_ID"),
            inverseJoinColumns = @JoinColumn(name = "CATEGORIA_ID")
    )
    private Set<Categoria> categorias;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaEstreno() {
        return fechaEstreno;
    }

    public void setFechaEstreno(String fechaEstreno) {
        this.fechaEstreno = fechaEstreno;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Funcion getFuncion() {
        return funcion;
    }

    public void setFuncion(Funcion funcion) {
        this.funcion = funcion;
    }

    public Set<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(Set<Categoria> categorias) {
        this.categorias = categorias;
    }
}
