package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Categoria;
import org.springframework.data.repository.CrudRepository;

public interface CategoriaRepository extends CrudRepository<Categoria, Long> {
}
