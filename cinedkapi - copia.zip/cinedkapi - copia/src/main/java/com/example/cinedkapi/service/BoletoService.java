package com.example.cinedkapi.service;

import com.example.cinedkapi.model.Boleto;
import com.example.cinedkapi.repository.BoletoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoletoService {

    @Autowired
    private BoletoRepository boletoRepository;

    public Boleto crearBoleto(Boleto boleto) {
        return boletoRepository.save(boleto);
    }

    public Iterable<Boleto> listarBoletos() {
        return boletoRepository.findAll();
    }

    public Boleto obtenerBoletoPorId(Long id) {
        return boletoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Boleto no encontrado"));
    }
}
