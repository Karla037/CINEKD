package com.example.cinedkapi.service;

import com.example.cinedkapi.model.Cartelera;
import com.example.cinedkapi.repository.CarteleraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CarteleraService {

    @Autowired
    private CarteleraRepository carteleraRepository;

    public Cartelera crearCartelera(Cartelera cartelera) {
        return carteleraRepository.save(cartelera);
    }

    public Iterable<Cartelera> listarCarteleras() {
        return carteleraRepository.findAll();
    }

    public Cartelera obtenerCarteleraPorId(Long id) {
        return carteleraRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cartelera no encontrada"));
    }
}
