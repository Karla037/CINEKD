package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Cine;
import org.springframework.data.repository.CrudRepository;

public interface CineRepository extends CrudRepository<Cine, Long> {
}
