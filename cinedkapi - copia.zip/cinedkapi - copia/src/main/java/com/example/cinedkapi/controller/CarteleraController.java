package com.example.cinedkapi.controller;

import com.example.cinedkapi.model.Cartelera;
import com.example.cinedkapi.service.CarteleraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carteleras")
public class CarteleraController {

    @Autowired
    private CarteleraService carteleraService;

    @PostMapping("/crear")
    public ResponseEntity<Cartelera> crearCartelera(@RequestBody Cartelera cartelera) {
        Cartelera nuevaCartelera = carteleraService.crearCartelera(cartelera);
        return ResponseEntity.ok(nuevaCartelera);
    }

    @GetMapping("/listar")
    public ResponseEntity<Iterable<Cartelera>> listarCarteleras() {
        return ResponseEntity.ok(carteleraService.listarCarteleras());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cartelera> obtenerCarteleraPorId(@PathVariable Long id) {
        Cartelera cartelera = carteleraService.obtenerCarteleraPorId(id);
        return ResponseEntity.ok(cartelera);
    }
}
