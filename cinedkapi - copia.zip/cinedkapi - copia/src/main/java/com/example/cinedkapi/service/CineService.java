package com.example.cinedkapi.service;

import com.example.cinedkapi.model.Cine;
import com.example.cinedkapi.repository.CineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CineService {

    @Autowired
    private CineRepository cineRepository;

    public Cine crearCine(Cine cine) {
        return cineRepository.save(cine);
    }

    public Iterable<Cine> listarCines() {
        return cineRepository.findAll();
    }
}
