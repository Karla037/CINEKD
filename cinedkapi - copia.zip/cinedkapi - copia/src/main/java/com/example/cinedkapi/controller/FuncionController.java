package com.example.cinedkapi.controller;

import com.example.cinedkapi.model.Funcion;
import com.example.cinedkapi.service.FuncionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/funciones")
public class FuncionController {

    @Autowired
    private FuncionService funcionService;

    @PostMapping("/crear")
    public ResponseEntity<Funcion> crearFuncion(@RequestBody Funcion funcion) {
        Funcion nuevaFuncion = funcionService.crearFuncion(funcion);
        return ResponseEntity.ok(nuevaFuncion);
    }

    @GetMapping("/listar")
    public ResponseEntity<Iterable<Funcion>> listarFunciones() {
        return ResponseEntity.ok(funcionService.listarFunciones());
    }
}
