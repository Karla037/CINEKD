package com.example.cinedkapi.model;

import jakarta.persistence.*;

@Entity
@Table(name = "BOLETOS")
public class Boleto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer noBoleto;

    @Column(nullable = false)
    private String ubicacion;

    @Column(nullable = false)
    private Integer noSala;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getNoBoleto() {
        return noBoleto;
    }

    public void setNoBoleto(Integer noBoleto) {
        this.noBoleto = noBoleto;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Integer getNoSala() {
        return noSala;
    }

    public void setNoSala(Integer noSala) {
        this.noSala = noSala;
    }
}
