package com.example.cinedkapi.service;

import com.example.cinedkapi.model.Sucursal;
import com.example.cinedkapi.repository.SucursalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SucursalService {

    @Autowired
    private SucursalRepository sucursalRepository;

    public Sucursal crearSucursal(Sucursal sucursal) {
        return sucursalRepository.save(sucursal);
    }

    public List<Sucursal> listarSucursales() {
        return sucursalRepository.findAll();
    }

    public Sucursal obtenerSucursalPorId(Long id) {
        return sucursalRepository.findById(id).orElseThrow(() -> new RuntimeException("Sucursal no encontrada"));
    }

    public Sucursal actualizarSucursal(Long id, Sucursal sucursalActualizada) {
        Sucursal sucursalExistente = sucursalRepository.findById(id).orElseThrow(() -> new RuntimeException("Sucursal no encontrada"));
        sucursalExistente.setNombre(sucursalActualizada.getNombre());
        sucursalExistente.setDireccion(sucursalActualizada.getDireccion());
        sucursalExistente.setTelefono(sucursalActualizada.getTelefono());
        sucursalExistente.setDireccionWeb(sucursalActualizada.getDireccionWeb());
        sucursalExistente.setDetalles(sucursalActualizada.getDetalles());
        return sucursalRepository.save(sucursalExistente);
    }

    public void eliminarSucursal(Long id) {
        sucursalRepository.deleteById(id);
    }
}
