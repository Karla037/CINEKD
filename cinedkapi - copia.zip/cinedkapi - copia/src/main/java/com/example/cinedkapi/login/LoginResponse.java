package com.example.cinedkapi.login;

public class LoginResponse {
    private String mensaje;

    // Getters y setters
    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
