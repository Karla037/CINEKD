package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Pelicula;
import org.springframework.data.repository.CrudRepository;

public interface PeliculaRepository extends CrudRepository<Pelicula, Long> {
}
