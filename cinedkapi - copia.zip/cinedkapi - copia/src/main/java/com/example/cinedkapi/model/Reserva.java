package com.example.cinedkapi.model;

import jakarta.persistence.*;

@Entity
@Table(name = "RESERVAS")
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer noAsiento;

    @ManyToOne
    @JoinColumn(name = "BOLETOS_ID", nullable = false)
    private Boleto boleto;

    @ManyToOne
    @JoinColumn(name = "PAGO_ID", nullable = false)
    private Pago pago;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getNoAsiento() {
        return noAsiento;
    }

    public void setNoAsiento(Integer noAsiento) {
        this.noAsiento = noAsiento;
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }
}
