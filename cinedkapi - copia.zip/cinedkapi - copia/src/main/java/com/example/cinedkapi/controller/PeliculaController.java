package com.example.cinedkapi.controller;

import com.example.cinedkapi.dto.PeliculaDTO;
import com.example.cinedkapi.model.Pelicula;
import com.example.cinedkapi.service.PeliculaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/peliculas")
public class PeliculaController {

    @Autowired
    private PeliculaService peliculaService;

    @PostMapping("/crear")
    public ResponseEntity<Pelicula> crearPelicula(@RequestBody PeliculaDTO peliculaDTO) {
        Pelicula nuevaPelicula = peliculaService.crearPelicula(peliculaDTO);
        return ResponseEntity.ok(nuevaPelicula);
    }

    @GetMapping("/listar")
    public ResponseEntity<Iterable<Pelicula>> listarPeliculas() {
        return ResponseEntity.ok(peliculaService.listarPeliculas());
    }
}
