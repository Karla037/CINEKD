package com.example.cinedkapi.controller;

import com.example.cinedkapi.model.Sucursal;
import com.example.cinedkapi.service.SucursalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sucursales")
public class SucursalController {

    @Autowired
    private SucursalService sucursalService;

    @PostMapping("/crear")
    public ResponseEntity<Sucursal> crearSucursal(@RequestBody Sucursal sucursal) {
        Sucursal nuevaSucursal = sucursalService.crearSucursal(sucursal);
        return ResponseEntity.ok(nuevaSucursal);
    }

    @GetMapping("/listar")
    public ResponseEntity<List<Sucursal>> listarSucursales() {
        List<Sucursal> sucursales = sucursalService.listarSucursales();
        return ResponseEntity.ok(sucursales);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sucursal> obtenerSucursal(@PathVariable Long id) {
        Sucursal sucursal = sucursalService.obtenerSucursalPorId(id);
        return ResponseEntity.ok(sucursal);
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Sucursal> actualizarSucursal(@PathVariable Long id, @RequestBody Sucursal sucursalActualizada) {
        Sucursal sucursal = sucursalService.actualizarSucursal(id, sucursalActualizada);
        return ResponseEntity.ok(sucursal);
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminarSucursal(@PathVariable Long id) {
        sucursalService.eliminarSucursal(id);
        return ResponseEntity.ok("Sucursal eliminada con éxito");
    }
}
