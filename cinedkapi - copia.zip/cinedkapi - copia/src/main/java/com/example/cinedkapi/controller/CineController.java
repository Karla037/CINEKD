package com.example.cinedkapi.controller;

import com.example.cinedkapi.model.Cine;
import com.example.cinedkapi.service.CineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cines")
public class CineController {

    @Autowired
    private CineService cineService;

    @PostMapping("/crear")
    public ResponseEntity<Cine> crearCine(@RequestBody Cine cine) {
        Cine nuevoCine = cineService.crearCine(cine);
        return ResponseEntity.ok(nuevoCine);
    }

    @GetMapping("/listar")
    public ResponseEntity<Iterable<Cine>> listarCines() {
        return ResponseEntity.ok(cineService.listarCines());
    }
}
