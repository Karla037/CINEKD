package com.example.cinedkapi.service;

import com.example.cinedkapi.model.Funcion;
import com.example.cinedkapi.repository.FuncionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FuncionService {

    @Autowired
    private FuncionRepository funcionRepository;

    public Funcion crearFuncion(Funcion funcion) {
        return funcionRepository.save(funcion);
    }

    public Iterable<Funcion> listarFunciones() {
        return funcionRepository.findAll();
    }
}
