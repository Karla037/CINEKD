package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Pago;
import org.springframework.data.repository.CrudRepository;

public interface PagoRepository extends CrudRepository<Pago, Long> {
}
