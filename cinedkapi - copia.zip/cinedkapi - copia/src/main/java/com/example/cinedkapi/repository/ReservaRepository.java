package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Reserva;
import org.springframework.data.repository.CrudRepository;

public interface ReservaRepository extends CrudRepository<Reserva, Long> {
}
