package com.example.cinedkapi.service;

import com.example.cinedkapi.model.Usuario;
import com.example.cinedkapi.model.Rol;
import com.example.cinedkapi.repository.UsuarioRepository;
import com.example.cinedkapi.repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    public Usuario registrarUsuario(Usuario usuario) {
        // Asignar el rol predeterminado "USER"
        Set<Rol> roles = new HashSet<>();
        Rol userRole = rolRepository.findByNombre("USER");
        roles.add(userRole);
        usuario.setRoles(roles);

        // Guardar el usuario en la base de datos
        return usuarioRepository.save(usuario);
    }

    public Usuario validarCredenciales(String correo, String contrasena) {
        // Buscar el usuario por correo y verificar contraseña
        Usuario usuario = usuarioRepository.findByCorreo(correo);
        if (usuario != null && usuario.getContrasena().equals(contrasena)) {
            return usuario;
        }
        return null;
    }
}
