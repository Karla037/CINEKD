package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Cartelera;
import org.springframework.data.repository.CrudRepository;

public interface CarteleraRepository extends CrudRepository<Cartelera, Long> {
}
