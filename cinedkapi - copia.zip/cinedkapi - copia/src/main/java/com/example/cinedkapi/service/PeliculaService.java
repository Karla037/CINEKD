package com.example.cinedkapi.service;

import com.example.cinedkapi.dto.PeliculaDTO;
import com.example.cinedkapi.model.Pelicula;
import com.example.cinedkapi.model.Funcion;
import com.example.cinedkapi.repository.FuncionRepository;
import com.example.cinedkapi.repository.PeliculaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PeliculaService {

    @Autowired
    private PeliculaRepository peliculaRepository;

    @Autowired
    private FuncionRepository funcionRepository;

    public Pelicula crearPelicula(PeliculaDTO peliculaDTO) {
        Pelicula pelicula = new Pelicula();
        pelicula.setNombre(peliculaDTO.getNombre());
        pelicula.setFechaEstreno(peliculaDTO.getFechaEstreno());
        pelicula.setDetalles(peliculaDTO.getDetalles());
        pelicula.setEstado(peliculaDTO.getEstado());

        // Asignar la función a la película
        Funcion funcion = funcionRepository.findById(peliculaDTO.getFuncionId())
                .orElseThrow(() -> new RuntimeException("Función no encontrada"));
        pelicula.setFuncion(funcion);

        return peliculaRepository.save(pelicula);
    }

    public Iterable<Pelicula> listarPeliculas() {
        return peliculaRepository.findAll();
    }
}

