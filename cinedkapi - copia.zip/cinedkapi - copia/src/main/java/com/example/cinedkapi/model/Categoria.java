package com.example.cinedkapi.model;

import jakarta.persistence.*;
import java.util.Set;

@Entity
@Table(name = "CATEGORIA")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String genero;

    @Column(nullable = false)
    private Integer clasificacionEdad;

    // Relación Many-to-Many con Pelicula
    @ManyToMany(mappedBy = "categorias")
    private Set<Pelicula> peliculas;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Integer getClasificacionEdad() {
        return clasificacionEdad;
    }

    public void setClasificacionEdad(Integer clasificacionEdad) {
        this.clasificacionEdad = clasificacionEdad;
    }

    public Set<Pelicula> getPeliculas() {
        return peliculas;
    }

    public void setPeliculas(Set<Pelicula> peliculas) {
        this.peliculas = peliculas;
    }
}
