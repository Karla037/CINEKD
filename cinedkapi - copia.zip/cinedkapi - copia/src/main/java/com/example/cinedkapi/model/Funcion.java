package com.example.cinedkapi.model;

import jakarta.persistence.*;

@Entity
@Table(name = "FUNCION")
public class Funcion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_FUNCION")  // Asegúrate de mapear el nombre correcto de la columna
    private Long idFuncion;

    @Column(nullable = false)
    private String sala;

    @Column(nullable = false)
    private String horario;

    @Column(nullable = false)
    private String fecha;

    @Column(nullable = false)
    private Integer limiteDePersonas;

    // Getters y setters
    public Long getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(Long idFuncion) {
        this.idFuncion = idFuncion;
    }

    public String getSala() {
        return sala;
    }

    public void setSala(String sala) {
        this.sala = sala;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Integer getLimiteDePersonas() {
        return limiteDePersonas;
    }

    public void setLimiteDePersonas(Integer limiteDePersonas) {
        this.limiteDePersonas = limiteDePersonas;
    }
}
