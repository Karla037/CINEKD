package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Boleto;
import org.springframework.data.repository.CrudRepository;

public interface BoletoRepository extends CrudRepository<Boleto, Long> {
}
