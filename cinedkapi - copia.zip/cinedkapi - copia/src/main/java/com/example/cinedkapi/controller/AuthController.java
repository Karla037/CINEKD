package com.example.cinedkapi.controller;

import com.example.cinedkapi.login.LoginRequest;
import com.example.cinedkapi.login.LoginResponse;
import com.example.cinedkapi.model.Usuario;
import com.example.cinedkapi.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/auth")
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        Usuario usuario = usuarioService.validarCredenciales(request.getCorreo(), request.getContrasena());
        if (usuario != null) {
            LoginResponse response = new LoginResponse();
            response.setMensaje("Inicio de sesión exitoso");
            return ResponseEntity.ok(response);
        } else {
            LoginResponse response = new LoginResponse();
            response.setMensaje("Correo o contraseña incorrectos");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }
}




