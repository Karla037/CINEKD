package com.example.cinedkapi.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Aquí deberías buscar al usuario por su nombre de usuario en tu base de datos.
        // Este es un ejemplo simple que devuelve un usuario estático:

        if ("admin".equals(username)) {
            return User.withUsername("admin")
                    .password("{noop}password")  // {noop} para indicar que no se utiliza un encoder para la contraseña
                    .roles("ADMIN")
                    .build();
        } else if ("vendedor".equals(username)) {
            return User.withUsername("vendedor")
                    .password("{noop}password")  // Aquí también puedes cambiar la contraseña
                    .roles("VENDEDOR")
                    .build();
        } else {
            // Si el usuario no se encuentra, lanzamos una excepción
            throw new UsernameNotFoundException("Usuario no encontrado: " + username);
        }
    }
}
