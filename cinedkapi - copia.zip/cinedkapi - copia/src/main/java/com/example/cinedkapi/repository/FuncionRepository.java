package com.example.cinedkapi.repository;

import com.example.cinedkapi.model.Funcion;
import org.springframework.data.repository.CrudRepository;

public interface FuncionRepository extends CrudRepository<Funcion, Long> {
}
