package cine;

public class registro {

}
