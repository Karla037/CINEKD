package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ErrorDatosActivity extends AppCompatActivity {
    private Button buttonRegresar, buttonInicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error_datos);

        buttonRegresar = findViewById(R.id.button_regresar);
        buttonInicio = findViewById(R.id.button_inicio);

        // Volver a la pantalla de facturación para intentar de nuevo
        buttonRegresar.setOnClickListener(v -> {
            finish(); // Regresa a la actividad anterior (DatosFacturacionActivity)
        });

        // Ir a la pantalla de cartelera cuando el usuario hace clic en "INICIO"
        buttonInicio.setOnClickListener(v -> {
            Intent intent = new Intent(ErrorDatosActivity.this, CarteleraActivity.class);
            startActivity(intent);
            finish(); // Opcional, para cerrar la pantalla de error
        });
    }
}
