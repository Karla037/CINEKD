package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.cine2.models.Movie;

public class DetallesActivity extends AppCompatActivity {

    private TextView tituloTextView, descripcionTextView, informacionTextView, sinopsisTextView;
    private ImageView detallesImageView;
    private Button buttonAtras, buttonSiguiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);

        // Inicializar vistas
        tituloTextView = findViewById(R.id.titulo);
        descripcionTextView = findViewById(R.id.descripcion);
        informacionTextView = findViewById(R.id.informacion);
        sinopsisTextView = findViewById(R.id.sinopsis);
        detallesImageView = findViewById(R.id.detalles2);
        buttonAtras = findViewById(R.id.button_atras);
        buttonSiguiente = findViewById(R.id.button_siguiente);

        // Obtener el objeto Movie del Intent
        Movie movie = getIntent().getParcelableExtra("movie");

        // Mostrar los detalles de la película
        if (movie != null) {
            mostrarDetallesPelicula(movie);
        } else {
            tituloTextView.setText("Película no disponible");
        }

        // Configurar los botones de navegación
        buttonAtras.setOnClickListener(v -> finish());  // Cierra la actividad actual

        // Configurar el botón para comprar boletos
        buttonSiguiente.setOnClickListener(v -> {
            // Iniciar la actividad de compra de boletos
            Intent intent = new Intent(DetallesActivity.this, CompraBoletoActivity.class);
            intent.putExtra("movie", movie);  // Pasar los detalles de la película a la actividad de compra de boletos
            startActivity(intent);
        });
    }

    // Método para mostrar los detalles de la película seleccionada
    private void mostrarDetallesPelicula(Movie movie) {
        tituloTextView.setText(movie.getTitle());
        detallesImageView.setImageResource(movie.getImageResource());
        descripcionTextView.setText(movie.getDescription());
        informacionTextView.setText(String.format("FECHA: %s\nHORARIO: %s\nSALA: %s", "20/10/2024", "7:00PM", "Sala B"));
        sinopsisTextView.setText(String.format("SINOPSIS\n%s", movie.getSynopsis()));
    }
}
