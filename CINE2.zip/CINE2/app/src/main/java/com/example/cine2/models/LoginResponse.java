package com.example.cine2.models;

public class LoginResponse {
    private String mensaje;  // Campo para manejar mensajes de éxito o error

    // Getters y Setters
    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
