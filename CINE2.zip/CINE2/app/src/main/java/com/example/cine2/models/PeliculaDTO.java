package com.example.cine2.models;

public class PeliculaDTO {
}
