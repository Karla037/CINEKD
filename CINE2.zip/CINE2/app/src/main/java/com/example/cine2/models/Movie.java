package com.example.cine2.models;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
    private String title;
    private int imageResource;
    private String synopsis;
    private String description;

    // Constructor
    public Movie(String title, int imageResource, String synopsis, String description) {
        this.title = title;
        this.imageResource = imageResource;
        this.synopsis = synopsis;
        this.description = description;
    }

    // Constructor usado para Parcel
    protected Movie(Parcel in) {
        title = in.readString();
        imageResource = in.readInt();
        synopsis = in.readString();
        description = in.readString();
    }

    // Parcelable Creator
    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeInt(imageResource);
        parcel.writeString(synopsis);
        parcel.writeString(description);
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public String getDescription() {
        return description;
    }
}

