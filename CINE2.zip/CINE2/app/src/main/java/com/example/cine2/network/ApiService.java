package com.example.cine2.network;

import com.example.cine2.models.UsuarioDTO;
import com.example.cine2.models.LoginRequest;
import com.example.cine2.models.LoginResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {

    // Endpoint para registrar usuario
    @POST("api/usuarios/registrar")
    Call<Void> registrarUsuario(@Body UsuarioDTO usuario);

    // Endpoint para iniciar sesión
    @POST("api/auth/login")
    Call<LoginResponse> login(@Body LoginRequest request);
}
