package com.example.cine2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.cine2.models.UsuarioDTO;
import com.example.cine2.network.ApiService;
import com.example.cine2.network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private Button registerBtn;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar Retrofit
        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);

        // Inicializar vistas
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input_register);
        registerBtn = findViewById(R.id.register_btn);

        // Configurar el botón de registrar
        registerBtn.setOnClickListener(v -> {
            String correo = emailInput.getText().toString();
            String contrasena = passwordInput.getText().toString();

            // Validar los campos de correo y contraseña
            if (correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Crear un objeto UsuarioDTO
            UsuarioDTO usuario = new UsuarioDTO(correo, contrasena);

            // Llamar al método de registro en la API
            Call<Void> call = apiService.registrarUsuario(usuario);
            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(RegisterActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                        finish();  // Finaliza la actividad y vuelve a la pantalla de inicio de sesión
                    } else {
                        Toast.makeText(RegisterActivity.this, "Error en el registro", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Toast.makeText(RegisterActivity.this, "Error en la conexión", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
}
