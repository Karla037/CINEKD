package com.example.cine2.models

import com.example.cine2.models.LoginRequest
import com.example.cine2.models.LoginResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("api/usuarios") //  coincide con el endpoint en Spring Boot
    fun login(@Body loginRequest: LoginRequest): Call<LoginResponse>
}
