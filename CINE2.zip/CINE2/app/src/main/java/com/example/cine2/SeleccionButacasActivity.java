package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SeleccionButacasActivity extends AppCompatActivity {

    private TextView tituloTextView, infoSucursalTextView, seleccionarButacasLabel;
    private GridLayout gridButacas;
    private Button buttonCancelar, buttonContinuar;

    private int totalBoletos; // El número total de boletos seleccionados
    private int boletosSeleccionados = 0; // Contador de butacas seleccionadas

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion_butacas);

        initViews();
        fetchIntentData();
        setupButtons();
        configureSeats();
    }

    private void initViews() {
        tituloTextView = findViewById(R.id.titulo_pelicula);
        infoSucursalTextView = findViewById(R.id.info_sucursal);
        seleccionarButacasLabel = findViewById(R.id.seleccionar_butacas_label);
        gridButacas = findViewById(R.id.grid_butacas);
        buttonCancelar = findViewById(R.id.button_cancelar);
        buttonContinuar = findViewById(R.id.button_continuar);
    }

    private void fetchIntentData() {
        String tituloPelicula = getIntent().getStringExtra("tituloPelicula");
        String infoSucursal = getIntent().getStringExtra("infoSucursal");
        totalBoletos = getIntent().getIntExtra("totalBoletos", 0);

        if (totalBoletos == 0) {
            Toast.makeText(this, "No se ha seleccionado ningún boleto.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Total de boletos: " + totalBoletos, Toast.LENGTH_SHORT).show();
        }

        tituloTextView.setText(tituloPelicula);
        infoSucursalTextView.setText(infoSucursal);
    }

    private void setupButtons() {
        buttonContinuar.setEnabled(false);
        buttonCancelar.setOnClickListener(v -> finish());
        buttonContinuar.setOnClickListener(v -> continueToBilling());
    }

    private void continueToBilling() {
        // Mensaje de confirmación
        Toast.makeText(this, "Continuando a la facturación...", Toast.LENGTH_SHORT).show();

        // Intent para iniciar la actividad de facturación
        Intent intent = new Intent(SeleccionButacasActivity.this, DatosFacturacionActivity.class);

        // Pasar datos a la siguiente actividad
        intent.putExtra("totalBoletos", totalBoletos);
        intent.putExtra("tituloPelicula", getIntent().getStringExtra("tituloPelicula"));
        intent.putExtra("infoSucursal", getIntent().getStringExtra("infoSucursal"));

        // Iniciar la actividad de facturación
        startActivity(intent);
    }

    private void configureSeats() {
        // Configurar los botones de las butacas
        for (int i = 0; i < gridButacas.getChildCount(); i++) {
            Button seat = (Button) gridButacas.getChildAt(i);
            seat.setBackground(ContextCompat.getDrawable(this, R.drawable.free_seat_indicator));
            seat.setOnClickListener(this::handleSeatSelection);
        }
    }

    private void handleSeatSelection(View view) {
        Button butaca = (Button) view;
        if (boletosSeleccionados < totalBoletos || butaca.isSelected()) {
            boolean isSelected = !butaca.isSelected();
            butaca.setSelected(isSelected);
            butaca.setBackground(ContextCompat.getDrawable(this, isSelected ? R.drawable.selected_seat_indicator : R.drawable.free_seat_indicator));

            boletosSeleccionados += (isSelected ? 1 : -1);
            buttonContinuar.setEnabled(boletosSeleccionados == totalBoletos);
        } else {
            Toast.makeText(this, "Ya has seleccionado el máximo de " + totalBoletos + " butacas.", Toast.LENGTH_SHORT).show();
        }
    }
}
