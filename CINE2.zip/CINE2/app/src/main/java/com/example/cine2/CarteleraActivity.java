package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cine2.models.Movie;

import java.util.ArrayList;
import java.util.List;

public class CarteleraActivity extends AppCompatActivity {

    private EditText editTextSearch;
    private ImageView iconSearch;
    private TextView titleMovies;
    private ImageView kravenImage, badBoysImage, ozImage;
    private Button buttonDetailsKraven, buttonDetailsBadBoys, buttonDetailsMagoOz;

    // Lista de películas
    private List<Movie> movieList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.peliculas);

        // Inicializar vistas
        editTextSearch = findViewById(R.id.editText_search);
        iconSearch = findViewById(R.id.icon_search);
        titleMovies = findViewById(R.id.title_movies);
        kravenImage = findViewById(R.id.imageView2);
        badBoysImage = findViewById(R.id.imageView8);
        ozImage = findViewById(R.id.imageView7);
        buttonDetailsKraven = findViewById(R.id.button);
        buttonDetailsBadBoys = findViewById(R.id.button2);
        buttonDetailsMagoOz = findViewById(R.id.button3);

        // Inicializar lista de películas
        movieList = new ArrayList<>();
        movieList.add(new Movie("Kraven", R.drawable.kraven_image, "Kraven es un cazador...", "DIRECTORES: Adil El Arbi, Bilall Fallah\nGUIÓN: Chris Bremner; Will Beall\nGÉNERO: ACCIÓN\nRESTRICCIÓN: MAYORES DE 15"));
        movieList.add(new Movie("Bad Boys", R.drawable.bad_boys_image, "Los detectives de Miami regresan...", "DIRECTORES: Michael Bay\nGÉNERO: COMEDIA, ACCIÓN"));
        movieList.add(new Movie("El Mago de Oz", R.drawable.mago_oz_image, "Dorothy es transportada...", "DIRECTORES: Victor Fleming\nGÉNERO: FANTASÍA, AVENTURA"));

        // Configurar los botones para abrir la actividad de detalles
        setOnClickListeners();
    }

    private void setOnClickListeners() {
        buttonDetailsKraven.setOnClickListener(v -> abrirDetallesPelicula(movieList.get(0)));
        buttonDetailsBadBoys.setOnClickListener(v -> abrirDetallesPelicula(movieList.get(1)));
        buttonDetailsMagoOz.setOnClickListener(v -> abrirDetallesPelicula(movieList.get(2)));
    }

    // Método para abrir la actividad de detalles y pasar la información de la película
    private void abrirDetallesPelicula(Movie movie) {
        Intent intent = new Intent(CarteleraActivity.this, DetallesActivity.class);
        intent.putExtra("movie", movie);  // Pasamos el objeto Movie directamente
        startActivity(intent);
    }
}
