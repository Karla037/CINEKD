package com.example.cine2;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginBtn;
    private Button createAccountBtn; // Botón de crear cuenta

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginBtn = findViewById(R.id.login_btn);
        createAccountBtn = findViewById(R.id.create_acount_btn); // Botón para registrar nuevo usuario

        // Configurar click listener para el botón de inicio de sesión
        loginBtn.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();

            // Llamar al método para hacer el login
            new LoginTask().execute(username, password);
        });

        // Configurar click listener para el botón de crear cuenta
        createAccountBtn.setOnClickListener(v -> {
            // Abrir la pantalla de registro
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent); // Iniciar la actividad de registro
        });
    }

    // Clase AsyncTask para manejar la solicitud HTTP en segundo plano
    private class LoginTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String correo = params[0];
            String contrasena = params[1];

            try {
                // URL de tu archivo PHP en el servidor local (XAMPP)
                URL url = new URL("http://10.0.2.2/cine/login.php"); // Dirección del servidor
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                // Datos que serán enviados en la solicitud POST
                String postData = "&CORREO=" + correo + "&CONTRASEÑA=" + contrasena;

                // Enviar los datos al servidor
                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();

                // Leer la respuesta del servidor
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                return response.toString(); // Retorna la respuesta del servidor

            } catch (Exception e) {
                Log.e("LoginError", "Error durante la conexión", e);
                return "error";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // Manejar la respuesta del servidor
            if (result.equals("success")) {
                Toast.makeText(MainActivity.this, "Login exitoso", Toast.LENGTH_SHORT).show();
                // Aquí puedes redirigir al usuario a la siguiente pantalla
            } else {
                Toast.makeText(MainActivity.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

