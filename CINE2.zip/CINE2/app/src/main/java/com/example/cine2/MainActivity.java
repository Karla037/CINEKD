package com.example.cine2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cine2.models.LoginRequest;
import com.example.cine2.models.LoginResponse;
import com.example.cine2.network.ApiService;
import com.example.cine2.network.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginBtn;
    private Button createAccountBtn;

    private static final String TAG = "MainActivity";  // Nombre para los logs

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginBtn = findViewById(R.id.login_btn);
        createAccountBtn = findViewById(R.id.create_acount_btn);

        // Configurar click listener para el botón de inicio de sesión
        loginBtn.setOnClickListener(v -> {
            String correo = usernameInput.getText().toString();
            String contrasena = passwordInput.getText().toString();

            // Validar los campos
            if (correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(MainActivity.this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Llamar al método para iniciar sesión con Retrofit
            iniciarSesion(correo, contrasena);
        });

        // Configurar click listener para el botón de crear cuenta
        createAccountBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void iniciarSesion(String correo, String contrasena) {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setCorreo(correo);
        loginRequest.setContrasena(contrasena);

        ApiService apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<LoginResponse> call = apiService.login(loginRequest);

        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String mensaje = response.body().getMensaje();
                    if ("Inicio de sesión exitoso".equals(mensaje)) {
                        Intent intent = new Intent(MainActivity.this, CarteleraActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(MainActivity.this, mensaje, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.e(TAG, "Error en el inicio de sesión: " + response.code());
                    Toast.makeText(MainActivity.this, "Error en el inicio de sesión", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e(TAG, "Error en la conexión: " + t.getMessage());
                Toast.makeText(MainActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
